var hello = angular.module('hello', ['date-picker-directive', 'ui.router', 'ngAnimate'])
		.controller('HelloCtrl', function($scope, PersonService, $http){
			var s = $scope;
			var templateModel = {
				id:'',
                name: 'test',
                dob: new Date(),
                age: '23',
				gender: 'M',
				hobbies: {}, 
            } ;
			s.person = angular.copy(templateModel);
            s.persons=[];
            s.states=[{
				name:'Karnataka'
				}, {
					name:'Bihar',
				},{
					name:'Tamilnadu'
			}];
			//s.hobbies={"reading": "N", "swimming": "N", "playing": "N"};
            s.addItem = function(save) {//if save is true, create new instance

				/*if(PersonService.checkDups(s.persons, s.person.name)) {
					alert("Person with the name - " + s.person.name + " already exists");
					return false;
				}*/
				var newEntry = {
                    name: s.person.name,
                    dob: s.person.dob,
                    age: s.person.age,
					gender: s.person.gender,
					hobbies: s.person.hobbies,
					// state
                };
				if(save){//PUT HTTP method used for inserts
					$http.put('persons.json', newEntry)
						.success(function(){
							s.persons.push(angular.copy(s.person));
						})
					
				}
				
				                				
				s.person = templateModel;
            };

            s.getColor = function(person){
                if(person.age > 60){
                    return "warning";
                }
            }
			
			s.removeItem = function(index){
                s.persons.splice(index, 1);
            }
			
			s.addHobby = function(person, hobby){
				// if(!hobby)
                s.persons.person.hobbies.push(hobby);
            }
			
			s.getHobbies = function(person){
				var hobbies = "";
				if(person.hobbies){
					angular.forEach(person.hobbies, function(hobby){
						hobbies += '| '+hobby;
					})
				}		
				return hobbies;
            }
			
			//sorting
			s.sortField = undefined;
			s.reverse = false;

			s.sort = function (fieldName) {
			  if (s.sortField === fieldName) {
				s.reverse = !s.reverse;
			  } else {
				s.sortField = fieldName;
				s.reverse = false;
			  }
			};

			s.isSortUp = function (fieldName) {
			  return s.sortField === fieldName && !s.reverse;
			};
			s.isSortDown = function (fieldName) {
			  return s.sortField === fieldName && s.reverse;
			};

			s.validateAge = function(ngModelController) {
				
				if(!s.person.age)
					return
				
				if(s.person.age < 0){
					ngModelController.age.$invalid = true;
					ngModelController.$invalid = true;
				}
				else{
					ngModelController.age.$invalid = false;
					ngModelController.$invalid = false;
				}
			};
		
			s.editDetails = function(index) {
				s.person = angular.copy(s.persons[index]);

			};
			s.setSelected = function() {
			   console.log("show", arguments, this);
			   this.selected = 'selected';
			   if (s.lastSelected) {
			     s.lastSelected.selected = '';
			   }
			   this.selected = 'selected';
			   s.lastSelected = this;
			}
			//control the appearance and behavior of DOB 
			s.dateOptions = {
				maxDate: new Date()
			};
        })
		
		//PersonService
		
		.factory('PersonService', function() {
			function checkDuplicates(collection, searchParam) {
				//Business logic here
				var returnVal = false;
				console.log("Checking duplicates");		
				angular.forEach(collection, function(value, key) {
					if(value.name === searchParam)
					{
						returnVal = true;
						//break;
					}
				});
				
				return returnVal;
			}
			
			return {
				checkDups : checkDuplicates
			}
		})
		//directive
		.directive('button', function() {
			  return {
			    restrict: 'E',
			    compile: function(element, attributes) {
			      element.addClass('btn');
			      if ( attributes.type === 'submit' ) {
			        element.addClass('btn-primary');
			      }
			      if ( attributes.size ) {
			        element.addClass('btn-' + attributes.size);
			      }
			    }
			}
		})

	.config(function($stateProvider, $urlRouterProvider) {
    
    $urlRouterProvider.otherwise('/home');
    
    $stateProvider
        .state('about', {
            url: '/about',
            controller:function($scope){
            	$scope.pageClass = 'page-about'
            },
            views:{
            	 'topMenu': { templateUrl: 'templates/topMenu.tpl' },
            	'about':{templateUrl: 'templates/about.tpl'}
            }
		})

        .state('home', {
            url: '/home',
             controller:function($scope){
            	$scope.pageClass = 'page-home'
            },
            views: {
                '': { templateUrl: 'index.html' },
                'topMenu': { templateUrl: 'templates/topMenu.tpl' },
                'body': { 
                    templateUrl: 'templates/application.tpl'
                }
            }
        });  
});