describe('Testing HelloCtrl.addItem()', function () {
  var $scope;

  beforeEach(module('hello'));
  beforeEach(inject(function ($rootScope) {
    $scope = $rootScope.$new();
  }));
  
  function getController($controller) {
	return $controller('HelloCtrl', {
      $scope: $scope
    });
  }


  it('should add 2 items (person)', inject(function ($controller) {

    var person = {};
	var newItem = {
                name: 'aaa',
                age: 30,
				gender: 'M',
				hobbies: {}
            };
	var newItem2 = {
                name: 'bbb',
                age: 20,
				gender: 'F',
				hobbies: {}
            };

    var ctrl = getController($controller);
	
    //verify the initial setup
    //expect($scope.persons).toEqual([person]);

    //execute and verify results
    $scope.addItem(newItem);
	$scope.addItem(newItem2);
    expect($scope.persons.length).toEqual(2);
  }));
  
  eit('should remove an item from 2 items (person)', inject(function ($controller) {
  
	var newItem1 = {
                name: 'aaa',
                age: 30,
				gender: 'M',
				hobbies: {}
            };
			
	var newItem2 = {
                name: 'bbb',
                age: 20,
				gender: 'F',
				hobbies: {}
            };

    var ctrl = getController($controller);
	
	$scope.persons = [newItem1, newItem2];
	
    //execute and verify results
	$scope.removeItem(1);
	expect($scope.persons.length).toEqual(1);
  }));
});