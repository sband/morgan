/**
 * Created by pariwesh on 11/1/2014.
 *//*

sequences     : true,  // join consecutive statemets with the “comma operator”
    properties    : true,  // optimize property access: a["foo"] → a.foo
    dead_code     : true,  // discard unreachable code
    drop_debugger : true,  // discard “debugger” statements
    conditionals  : true,  // optimize if-s and conditional expressions
    comparisons   : true,  // optimize comparisons
    evaluate      : true,  // evaluate constant expressions
    booleans      : true,  // optimize boolean expressions
    loops         : true,  // optimize loops
    unused        : true,  // drop unused variables/functions
    hoist_funs    : true,  // hoist function declarations
    hoist_vars    : false, // hoist variable declarations
    if_return     : true,  // optimize if-s followed by return/continue
    join_vars     : true,  // join var declarations
    cascade       : true,  // try to cascade `right` into `left` in sequences
    side_effects  : true,  // drop side-effect-free statements
    warnings      : true,  // warn about potentially dangerous optimizations/code
    global_defs   : {}     // global definitions*/
module.exports = function(grunt){
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.initConfig({
        pkg:grunt.file.readJSON('package.json'),
        uglify:{
            options: {
//                drop_debugger : true,
                dead_code     : true,
                compress: {
                    global_defs: {
                        "DEBUG": false
                    },
                    dead_code: true
                },
                beautify: true,
                // the banner is inserted at the top of the output
                banner: '/*! <%= pkg.name %> <%= grunt.template.today("dd-mm-yyyy") %> */\n'
//                wrap:true,report:'gzip',
////               mangle:false,
//                except: ['jQuery', 'jqLite']
            },
            dev1:{
                files:{
                    "js/final.min.js":[
                        "bower_components/angular/angular.js",
                        "bower_components/ng-table/ng-table.min.js",
                        "public/js/*.js"
                        ] //can be array or single object
                }

            }
        }
    })
   grunt.registerTask('default',['uglify'])
}