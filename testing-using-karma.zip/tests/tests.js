/**
 * Created by pariwesh on 11/2/2014.
 */
describe('init', function(){
    beforeEach(function(){
        console.log('beforeEach');
    })
    it('test1', function(){
        console.error('error');

    })
    it('test21', function(){
        console.log('test21');
    })
})