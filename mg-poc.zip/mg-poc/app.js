main  = angular.module('main', ['listModule']);
main.run( function($http){
		$http.defaults.headers.common.ms_token='msd-1';
		$http.defaults.headers.post.post_token='sent with Post method';
		// $http.defaults.params.common.reqParam1= 'value';
});
main.value('data_url', 'data/');
main.service('dataService', ['$http','data_url', function($http, data_url){
	return {
		save:function(user){
			console.log('working service ');
			var promise = $http({
			url: data_url+user.firstName,
			method:'PUT',
			data:user,
			headers:{
				// token:'ms-token',
				location:'Mumbai'
			},
			timeout:7000
		});
			return promise;
		},
		delete:function(user){
			return $http.delete('data/'+user.firstName, {

			});
		},
		saveInStorage:function(users){
			localStorage.setItem('users', JSON.stringify(angular.toJson(users)));
		}
	}
}])

main.controller('formCtrl', ['$scope', '$http', 'dataService',
 function($scope, $http, dataService){
	var s= $scope;
	s.user={};
	s.success =true;
	 s.$parent.users = [];
	s.$parent.delete = function(selecterow){
		console.log('parent');
		var promise = dataService.delete(s.users[selecterow]);
		// promise.then()
		promise.success(function(){
			s.$parent.users.splice(selecterow,1);	
		});
	}
	
	console.log('initialize');
	s.user.firstName = 'John';
	s.save = function(){
		var promise = dataService.save(s.user);

		promise.success(function(response, status, headers, config){
			dataService.saveInStorage(s.users);
			s.$parent.users.push(angular.copy(s.user));	
			s.success = false;
		});
		promise.error(function(){

		});

				// s.user=null;
	}
}])