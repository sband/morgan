/**
* listModule Modul
*
* Description
*/
angular.module('listModule', [])
.controller('ListCtrl', ['$scope', function(s){
	s.getClass= function(user1){
		return user1.age > 40 ? 'red': 'green';
	}
	/*s.delete = function(selecterow){
		console.log('child');
		s.$parent.users.splice(selecterow,1);
	}*/
	
}])
.filter('filterName', function(collection, searchTerm){
	//Logic
	
})